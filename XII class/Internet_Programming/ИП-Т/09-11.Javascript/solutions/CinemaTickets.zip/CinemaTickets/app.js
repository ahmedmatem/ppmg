"use strict";

const screenings = {
    morning: {name: 'Сутрешна прожекция', price: 6},
    afternoon: {name: 'Следобедна прожекция', price: 8},
    evening: {name: 'Вечерна прожекция', price: 10}
}

const order = {screening: 'morning', quantity: 1};

function isValidQuantity(quantity) {
    return Number.isInteger(quantity) && quantity >= 1 && quantity <= 6;
}

function hasDiscount() {
    return document.getElementById('student-discount').checked == true;
}

// form elements
const form = document.querySelector('#ticket-form');
const screening = document.querySelector('#screening');
const quantity = document.querySelector('#quantity');
const message = document.querySelector('#message');

// section summary panel
const screeningName = document.querySelector('#screening-name');
const unitPrice = document.querySelector('#unit-price');
const subtotal = document.querySelector('#subtotal');
const discountAmount = document.querySelector('#discount-amount');
const total = document.querySelector('#total');

function showScreeningInfo() {
    const currentScreening = screenings[order.screening];
    screeningName.textContent = currentScreening.name;
    unitPrice.textContent = (currentScreening.price).toFixed(2) + ' £';
}

showScreeningInfo();

function showResult() {
    const currentScreening = screenings[order.screening];
    const subtotalPrice = order.quantity * currentScreening.price;
    const discountPrice = hasDiscount() ? subtotalPrice * 0.2 : 0;
    const totalPrice = subtotalPrice - discountPrice;
    subtotal.textContent = subtotalPrice.toFixed(2) + ' £';
    discountAmount.textContent = discountPrice.toFixed(2) + ' £';
    total.textContent = totalPrice.toFixed(2) + ' £';
}

function reset() {
    subtotal.textContent = '-';
    discountAmount.textContent = '-';
    total.textContent = '-';
}

function screeningChanged(event){
    order.screening = event.target.value;
    showScreeningInfo();
    reset();
}
screening.addEventListener('change', screeningChanged);


function quantityChanged(event) {
    reset();
    const q = Number(event.target.value);
    if(isValidQuantity(q)){
        order.quantity = q;
        message.textContent = 'Натисни бутона "Изчисли сумата"';
    } else {
        message.textContent = 'Броят на билетите трябва да е между 1 и 6.';
    }
}
quantity.addEventListener('input', quantityChanged);

function submit(event) {
    event.preventDefault();

    if(isValidQuantity(order.quantity)){
        showScreeningInfo();
        showResult();
    }
}
form.addEventListener('submit', submit);
