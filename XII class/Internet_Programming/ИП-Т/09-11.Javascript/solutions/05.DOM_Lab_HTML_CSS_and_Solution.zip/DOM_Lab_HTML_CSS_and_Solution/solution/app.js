"use strict";

// 1. Намираме елементите. app.js се свързва с defer в HTML.
const lab = document.querySelector("#lab");
const description = document.querySelector("#description");
const link = document.querySelector("#resource-link");
const output = document.querySelector("#output");

// 2. Променяме текст и атрибути.
description.textContent = "Промених текста чрез JavaScript!";
link.textContent = "Ръководство за DOM в MDN";
link.href = "https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Scripting/DOM_scripting";
link.setAttribute("title", "Отвори учебния материал за DOM");

// 3. Създаваме и добавяме нов абзац.
const note = document.createElement("p");
note.textContent = "Този абзац е създаден с createElement.";
output.append(note);

// 4. Добавяме текстов възел.
const extraText = document.createTextNode(" Вече мога да променям DOM.");
description.appendChild(extraText);

// 5. Преместваме съществуващ елемент, без да го копираме.
const linkRow = document.querySelector("#link-row");
lab.append(linkRow);

// 6. Пример за inline стилове. След тях показваме еквивалент с клас.
note.style.color = "#175944";
note.style.backgroundColor = "#e5f4ef";
note.style.padding = "12px";
// Премахваме трите inline стойности, за да управляваме вида чрез CSS.
note.style.color = "";
note.style.backgroundColor = "";
note.style.padding = "";
note.classList.add("notice");

// 7. Създаваме временен елемент и го премахваме.
const temporary = document.createElement("p");
temporary.textContent = "Временен текст";
output.append(temporary);
temporary.remove();

// 8. Променяме няколко елемента.
const topics = document.querySelectorAll(".topic");
for (const topic of topics) {
  topic.classList.add("topic-mark");
}

// 9. Реакция на бутон: клас и видимост.
const highlightButton = document.querySelector("#highlight-button");
const hintButton = document.querySelector("#hint-button");
const hint = document.querySelector("#hint");

highlightButton.addEventListener("click", function () {
  description.classList.toggle("highlight");
});
hintButton.addEventListener("click", function () {
  hint.hidden = !hint.hidden;
});

// 10. Малко практическо приложение: добавяне и премахване на задачи.
const taskForm = document.querySelector("#task-form");
const taskInput = document.querySelector("#task-input");
const taskList = document.querySelector("#task-list");
const message = document.querySelector("#message");

function createTask(text) {
  const item = document.createElement("li");
  const label = document.createElement("span");
  label.textContent = text;
  const removeButton = document.createElement("button");
  removeButton.type = "button";
  removeButton.textContent = "Изтрий";
  removeButton.addEventListener("click", function () {
    item.remove();
  });
  item.append(label, removeButton);
  return item;
}

function handleSubmit(event) {
  event.preventDefault();
  const text = taskInput.value.trim();
  if (text === "") {
    message.textContent = "Въведи текст за задачата.";
    taskInput.focus();
    return;
  }
  taskList.append(createTask(text));
  taskInput.value = "";
  message.textContent = "";
  taskInput.focus();
}

taskForm.addEventListener("submit", handleSubmit);
