"use strict";

const products = {
  camera: { id: "camera", name: "Уебкамера", price: 30, available: true },
  headset: { id: "headset", name: "Слушалки", price: 45, available: true },
  keyboard: { id: "keyboard", name: "Клавиатура", price: 50, available: false }
};
const order = {
  productId: "camera", quantity: 1
};

function calculateTotal(price, quantity) {
  return price * quantity;
}

function isValidQuantity(value) {
  return Number.isInteger(value)
    && value >= 1 && value <= 5;
}

const form = document.querySelector("#order-form");
const productSelect = document.querySelector("#product");
const quantityInput = document.querySelector("#quantity");
const productName = document.querySelector("#product-name");
const unitPrice = document.querySelector("#unit-price");
const total = document.querySelector("#total");
const message = document.querySelector("#message");
const resetButton = document.querySelector("#reset");

function updateSummary() {
  const product = products[order.productId];
  productName.textContent = product.name;
  unitPrice.textContent = product.price.toFixed(2) + " €";
  total.textContent = calculateTotal(
    product.price, order.quantity
  ).toFixed(2) + " €";
}
updateSummary();

function handleProductChange() {
  order.productId = productSelect.value;
  message.textContent = "";
  updateSummary();
}

productSelect.addEventListener(
  "change", handleProductChange
);

function handleQuantityInput(event) {
  const quantity = Number(event.currentTarget.value);
  message.textContent = isValidQuantity(quantity)
    ? "Натиснете Изчисли."
    : "Въведете цяло число от 1 до 5.";
}
quantityInput.addEventListener(
  "input", handleQuantityInput
);

function handleSubmit(event) {
  event.preventDefault();
  const quantity = Number(quantityInput.value);
  if (!isValidQuantity(quantity)) {
    message.textContent = "Въведете цяло число от 1 до 5.";
    return;
  }
  order.quantity = quantity;
  updateSummary();
  message.textContent = "Сумата е обновена.";
}

form.addEventListener("submit", handleSubmit);

function handleReset() {
  order.productId = "camera";
  order.quantity = 1;
  productSelect.value = "camera";
  quantityInput.value = "1";
  message.textContent = "Начални стойности.";
  updateSummary();
}
resetButton.addEventListener("click", handleReset);

// Новите елементи в готовия HTML.
const productList = document.querySelector("#product-list");
const searchInput = document.querySelector("#search");
const onlyAvailable = document.querySelector("#only-available");
const resultCount = document.querySelector("#result-count");
const emptyMessage = document.querySelector("#empty-message");

function syncSelection() {
  const cards = productList.querySelectorAll(".product-card");
  for (const card of cards) {
    const selected = card.dataset.productId === order.productId;
    card.classList.toggle("is-selected", selected);
    const button = card.querySelector("button");
    button.textContent = selected ? "Избран" : "Избери";
    button.setAttribute("aria-pressed", String(selected));
  }
}

function createProductCard(product) {
  const card = document.createElement("article");
  card.classList.add("product-card");
  card.dataset.productId = product.id;
  card.classList.toggle("is-unavailable", !product.available);

  const title = document.createElement("h3");
  title.textContent = product.name;
  const price = document.createElement("p");
  price.textContent = product.price.toFixed(2) + " €";
  const status = document.createElement("p");
  status.textContent = product.available ? "В наличност" : "Изчерпан";
  const button = document.createElement("button");
  button.type = "button";
  button.textContent = "Избери";
  button.disabled = !product.available;
  button.addEventListener("click", function () {
    order.productId = product.id;
    productSelect.value = product.id;
    message.textContent = "";
    updateSummary();
    syncSelection();
  });

  card.append(title, price, status, button);
  return card;
}

function renderProducts(items) {
  productList.replaceChildren();
  for (const product of items) {
    const card = createProductCard(product);
    productList.append(card);
  }
  resultCount.textContent = "Намерени продукти: " + items.length;
  emptyMessage.hidden = items.length > 0;
  syncSelection();
}

function applyFilters() {
  const keyword = searchInput.value.trim().toLowerCase();
  const filtered = [];
  for (const product of Object.values(products)) {
    const matchesName = product.name.toLowerCase().includes(keyword);
    const matchesStock = !onlyAvailable.checked || product.available;
    if (matchesName && matchesStock) {
      filtered.push(product);
    }
  }
  renderProducts(filtered);
}

searchInput.addEventListener("input", applyFilters);
onlyAvailable.addEventListener("change", applyFilters);
// Старите обработчици обновяват order и сумата. Тези обновяват картите.
productSelect.addEventListener("change", syncSelection);
resetButton.addEventListener("click", syncSelection);
applyFilters();
