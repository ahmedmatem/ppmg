"use strict";

const products = {
  camera: { id: "camera", name: "Уебкамера", price: 30, available: true },
  headset: { id: "headset", name: "Слушалки", price: 45, available: true },
  keyboard: { id: "keyboard", name: "Клавиатура", price: 50, available: false }
};
const order = {
  productId: "camera", quantity: 1
};

function calculateTotal(price, quantity) {
  return price * quantity;
}

function isValidQuantity(value) {
  return Number.isInteger(value)
    && value >= 1 && value <= 5;
}

const form = document.querySelector("#order-form");
const productSelect = document.querySelector("#product");
const quantityInput = document.querySelector("#quantity");
const productName = document.querySelector("#product-name");
const unitPrice = document.querySelector("#unit-price");
const total = document.querySelector("#total");
const message = document.querySelector("#message");
const resetButton = document.querySelector("#reset");

function updateSummary() {
  const product = products[order.productId];
  productName.textContent = product.name;
  unitPrice.textContent = product.price.toFixed(2) + " €";
  total.textContent = calculateTotal(
    product.price, order.quantity
  ).toFixed(2) + " €";
}
updateSummary();

function handleProductChange() {
  order.productId = productSelect.value;
  message.textContent = "";
  updateSummary();
}

productSelect.addEventListener(
  "change", handleProductChange
);

function handleQuantityInput(event) {
  const quantity = Number(event.currentTarget.value);
  message.textContent = isValidQuantity(quantity)
    ? "Натиснете Изчисли."
    : "Въведете цяло число от 1 до 5.";
}
quantityInput.addEventListener(
  "input", handleQuantityInput
);

function handleSubmit(event) {
  event.preventDefault();
  const quantity = Number(quantityInput.value);
  if (!isValidQuantity(quantity)) {
    message.textContent = "Въведете цяло число от 1 до 5.";
    return;
  }
  order.quantity = quantity;
  updateSummary();
  message.textContent = "Сумата е обновена.";
}

form.addEventListener("submit", handleSubmit);

function handleReset() {
  order.productId = "camera";
  order.quantity = 1;
  productSelect.value = "camera";
  quantityInput.value = "1";
  message.textContent = "Начални стойности.";
  updateSummary();
}
resetButton.addEventListener("click", handleReset);


// Тук добавяме DOM кода от втория урок.
