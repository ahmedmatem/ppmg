using Microsoft.EntityFrameworkCore;
using CinemaBooking.Data;
using CinemaBooking.Models.Entities;
using CinemaBooking.Services.Interfaces;

namespace CinemaBooking.Services.Implementations
{
    public class ScreeningService : IScreeningService
    {
        private readonly CinemaDbContext _context;

        public ScreeningService(CinemaDbContext context)
        {
            _context = context;
        }

        public async Task<List<Screening>> GetAllAsync()
        {
            return await _context.Screenings
                .Include(s => s.Movie)
                .OrderBy(s => s.StartTime)
                .ToListAsync();
        }

        public async Task<Screening?> GetByIdAsync(int id)
        {
            return await _context.Screenings
                .Include(s => s.Movie)
                .FirstOrDefaultAsync(s => s.Id == id);
        }

        public async Task<Screening> CreateAsync(Screening screening)
        {
            _context.Screenings.Add(screening);
            await _context.SaveChangesAsync();
            return screening;
        }

        public async Task<bool> UpdateAsync(Screening screening)
        {
            if (!await _context.Screenings.AnyAsync(s => s.Id == screening.Id))
                return false;

            _context.Screenings.Update(screening);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteAsync(int id)
        {
            var screening = await _context.Screenings.FindAsync(id);
            if (screening == null)
                return false;

            _context.Screenings.Remove(screening);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<List<Screening>> GetUpcomingByMovieAsync(int movieId)
        {
            var now = DateTime.UtcNow;
            return await _context.Screenings
                .Where(s => s.MovieId == movieId && s.StartTime > now)
                .OrderBy(s => s.StartTime)
                .ToListAsync();
        }
    }
}
