using Microsoft.EntityFrameworkCore;
using CinemaBooking.Data;
using CinemaBooking.Models.Entities;
using CinemaBooking.Services.Interfaces;

namespace CinemaBooking.Services.Implementations
{
    public class MovieService : IMovieService
    {
        private readonly CinemaDbContext _context;

        public MovieService(CinemaDbContext context)
        {
            _context = context;
        }

        public async Task<List<Movie>> GetAllAsync()
        {
            return await _context.Movies
                .OrderBy(m => m.Title)
                .ToListAsync();
        }

        public async Task<Movie?> GetByIdAsync(int id)
        {
            return await _context.Movies
                .Include(m => m.Screenings)
                .FirstOrDefaultAsync(m => m.Id == id);
        }

        public async Task<Movie> CreateAsync(Movie movie)
        {
            _context.Movies.Add(movie);
            await _context.SaveChangesAsync();
            return movie;
        }

        public async Task<bool> UpdateAsync(Movie movie)
        {
            if (!await _context.Movies.AnyAsync(m => m.Id == movie.Id))
                return false;

            _context.Movies.Update(movie);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteAsync(int id)
        {
            var movie = await _context.Movies.FindAsync(id);
            if (movie == null)
                return false;

            _context.Movies.Remove(movie);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<List<Movie>> GetNowShowingAsync()
        {
            var now = DateTime.UtcNow;
            return await _context.Screenings
                .Where(s => s.StartTime > now)
                .Select(s => s.Movie)
                .Distinct()
                .OrderBy(m => m.Title)
                .ToListAsync();
        }
    }
}
