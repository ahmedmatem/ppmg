using Microsoft.EntityFrameworkCore;
using CinemaBooking.Data;
using CinemaBooking.Models.Entities;
using CinemaBooking.Services.Interfaces;

namespace CinemaBooking.Services.Implementations
{
    public class BookingService : IBookingService
    {
        private readonly CinemaDbContext _context;
        private readonly INotificationService _notificationService;

        public BookingService(CinemaDbContext context, INotificationService notificationService)
        {
            _context = context;
            _notificationService = notificationService;
        }

        public async Task<bool> CreateBookingAsync(int customerId, int screeningId, int seats)
        {
            if (seats <= 0)
                return false;

            var customer = await _context.Customers.FindAsync(customerId);
            var screening = await _context.Screenings.FindAsync(screeningId);

            if (customer == null || screening == null)
                return false;

            if (!customer.IsActive)
                return false;

            if (screening.StartTime <= DateTime.UtcNow)
                return false; // не позволяваме резервация за минала или започнала прожекция

            if (screening.AvailableSeats < seats)
                return false;

            var totalPrice = seats * screening.TicketPrice;

            var booking = new Booking
            {
                CustomerId = customerId,
                ScreeningId = screeningId,
                Seats = seats,
                TotalPrice = totalPrice,
                BookedAt = DateTime.UtcNow,
                IsCancelled = false
            };

            _context.Bookings.Add(booking);
            screening.AvailableSeats -= seats;

            await _context.SaveChangesAsync();

            await _notificationService.SendAsync(
                customer.Email,
                "Успешна резервация",
                $"Филм: {screening.Id}, места: {seats}, цена: {totalPrice:F2} лв.");

            return true;
        }

        public async Task<bool> CancelBookingAsync(int bookingId)
        {
            var booking = await _context.Bookings
                .Include(b => b.Screening)
                .Include(b => b.Customer)
                .FirstOrDefaultAsync(b => b.Id == bookingId);

            if (booking == null)
                return false;

            if (booking.IsCancelled)
                return false;

            booking.IsCancelled = true;
            booking.Screening.AvailableSeats += booking.Seats;

            await _context.SaveChangesAsync();

            await _notificationService.SendAsync(
                booking.Customer.Email,
                "Отменена резервация",
                $"Вашата резервация за прожекция {booking.Screening.Id} беше отменена.");

            return true;
        }

        public async Task<Booking?> GetBookingAsync(int bookingId)
        {
            return await _context.Bookings
                .Include(b => b.Screening)
                .Include(b => b.Customer)
                .FirstOrDefaultAsync(b => b.Id == bookingId);
        }

        public async Task<List<Booking>> GetActiveBookingsForCustomerAsync(int customerId)
        {
            return await _context.Bookings
                .Where(b => b.CustomerId == customerId && !b.IsCancelled)
                .Include(b => b.Screening)
                .OrderBy(b => b.BookedAt)
                .ToListAsync();
        }
    }
}
