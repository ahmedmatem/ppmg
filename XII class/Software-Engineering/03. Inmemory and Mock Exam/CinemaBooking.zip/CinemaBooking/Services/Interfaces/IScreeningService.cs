using CinemaBooking.Models.Entities;

namespace CinemaBooking.Services.Interfaces
{
    public interface IScreeningService
    {
        Task<List<Screening>> GetAllAsync();
        Task<Screening?> GetByIdAsync(int id);
        Task<Screening> CreateAsync(Screening screening);
        Task<bool> UpdateAsync(Screening screening);
        Task<bool> DeleteAsync(int id);

        Task<List<Screening>> GetUpcomingByMovieAsync(int movieId);
    }
}
