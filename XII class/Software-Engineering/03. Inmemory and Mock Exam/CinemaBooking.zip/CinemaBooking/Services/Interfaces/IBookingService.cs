using CinemaBooking.Models.Entities;

namespace CinemaBooking.Services.Interfaces
{
    public interface IBookingService
    {
        /// <summary>
        /// Създава нова резервация, ако има достатъчно свободни места и клиентът е активен.
        /// Изчислява TotalPrice на база Seats × TicketPrice.
        /// Връща true при успех, false при неуспех.
        /// </summary>
        Task<bool> CreateBookingAsync(int customerId, int screeningId, int seats);

        /// <summary>
        /// Отменя резервация и връща местата като свободни.
        /// </summary>
        Task<bool> CancelBookingAsync(int bookingId);

        Task<Booking?> GetBookingAsync(int bookingId);

        Task<List<Booking>> GetActiveBookingsForCustomerAsync(int customerId);
    }
}
