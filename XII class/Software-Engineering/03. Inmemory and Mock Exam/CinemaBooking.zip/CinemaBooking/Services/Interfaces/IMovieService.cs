using CinemaBooking.Models.Entities;

namespace CinemaBooking.Services.Interfaces
{
    public interface IMovieService
    {
        Task<List<Movie>> GetAllAsync();
        Task<Movie?> GetByIdAsync(int id);
        Task<Movie> CreateAsync(Movie movie);
        Task<bool> UpdateAsync(Movie movie);
        Task<bool> DeleteAsync(int id);

        /// <summary>
        /// Връща филми, които имат прожекции с начало в бъдеще.
        /// </summary>
        Task<List<Movie>> GetNowShowingAsync();
    }
}
