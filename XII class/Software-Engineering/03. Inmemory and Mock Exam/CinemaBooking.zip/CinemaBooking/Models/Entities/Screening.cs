namespace CinemaBooking.Models.Entities
{
    public class Screening
    {
        public int Id { get; set; }

        public int MovieId { get; set; }
        public Movie Movie { get; set; } = null!;

        public DateTime StartTime { get; set; }

        public string Room { get; set; } = null!;

        public int TotalSeats { get; set; }

        public int AvailableSeats { get; set; }

        public decimal TicketPrice { get; set; }

        public ICollection<Booking> Bookings { get; set; } = new List<Booking>();
    }
}
