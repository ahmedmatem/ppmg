namespace CinemaBooking.Models.Entities
{
    public class Movie
    {
        public int Id { get; set; }

        public string Title { get; set; } = null!;

        public string Genre { get; set; } = null!;

        public int DurationMinutes { get; set; }

        public string Rating { get; set; } = null!; // напр. G, PG-13, R

        public ICollection<Screening> Screenings { get; set; } = new List<Screening>();
    }
}
