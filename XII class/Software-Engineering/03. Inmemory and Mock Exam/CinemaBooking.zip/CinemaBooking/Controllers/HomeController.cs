using Microsoft.AspNetCore.Mvc;

namespace CinemaBooking.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return Content("CinemaBooking app is running. Използвайте проекта за упражнение на Unit тестове с EF Core InMemory и Mock обекти.");
        }
    }
}
