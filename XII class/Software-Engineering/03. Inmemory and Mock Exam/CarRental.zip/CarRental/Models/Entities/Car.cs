namespace CarRental.Models.Entities
{
    public class Car
    {
        public int Id { get; set; }

        public string Make { get; set; } = null!;

        public string Model { get; set; } = null!;

        public string PlateNumber { get; set; } = null!;

        public decimal DailyRate { get; set; }

        public bool IsAvailable { get; set; } = true;

        public ICollection<Rental> Rentals { get; set; } = new List<Rental>();
    }
}
