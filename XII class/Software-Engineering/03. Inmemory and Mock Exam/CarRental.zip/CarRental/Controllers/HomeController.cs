using Microsoft.AspNetCore.Mvc;

namespace CarRental.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return Content("CarRental app is running. Използвайте проекта за упражнение на Unit тестове с EF Core InMemory и Mock обекти.");
        }
    }
}
