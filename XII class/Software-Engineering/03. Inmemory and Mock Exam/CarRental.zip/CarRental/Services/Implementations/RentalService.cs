using Microsoft.EntityFrameworkCore;
using CarRental.Data;
using CarRental.Models.Entities;
using CarRental.Services.Interfaces;

namespace CarRental.Services.Implementations
{
    public class RentalService : IRentalService
    {
        private readonly CarRentalDbContext _context;
        private readonly INotificationService _notificationService;

        public RentalService(CarRentalDbContext context, INotificationService notificationService)
        {
            _context = context;
            _notificationService = notificationService;
        }

        public async Task<bool> CreateRentalAsync(int customerId, int carId, DateTime startDate, DateTime endDate)
        {
            if (startDate.Date > endDate.Date)
                return false;

            var customer = await _context.Customers.FindAsync(customerId);
            var car = await _context.Cars.FindAsync(carId);

            if (customer == null || car == null)
                return false;

            if (!customer.IsActive)
                return false;

            if (!car.IsAvailable)
                return false;

            var days = (endDate.Date - startDate.Date).Days + 1;
            if (days <= 0)
                return false;

            var totalPrice = days * car.DailyRate;

            var rental = new Rental
            {
                CustomerId = customerId,
                CarId = carId,
                StartDate = startDate.Date,
                EndDate = endDate.Date,
                TotalPrice = totalPrice,
                IsReturned = false
            };

            _context.Rentals.Add(rental);
            car.IsAvailable = false;

            await _context.SaveChangesAsync();

            await _notificationService.SendAsync(
                customer.Email,
                "Вашият наем е създаден",
                $"Автомобил: {car.Make} {car.Model}, период: {startDate:dd.MM.yyyy} - {endDate:dd.MM.yyyy}, цена: {totalPrice:F2} лв.");

            return true;
        }

        public async Task<bool> ReturnCarAsync(int rentalId)
        {
            var rental = await _context.Rentals
                .Include(r => r.Car)
                .Include(r => r.Customer)
                .FirstOrDefaultAsync(r => r.Id == rentalId);

            if (rental == null)
                return false;

            if (rental.IsReturned)
                return false;

            rental.IsReturned = true;
            rental.Car.IsAvailable = true;

            await _context.SaveChangesAsync();

            await _notificationService.SendAsync(
                rental.Customer.Email,
                "Връщане на автомобил",
                $"Благодарим ви, че върнахте автомобила: {rental.Car.Make} {rental.Car.Model}.");

            return true;
        }

        public async Task<Rental?> GetRentalAsync(int rentalId)
        {
            return await _context.Rentals
                .Include(r => r.Car)
                .Include(r => r.Customer)
                .FirstOrDefaultAsync(r => r.Id == rentalId);
        }

        public async Task<List<Rental>> GetActiveRentalsForCustomerAsync(int customerId)
        {
            return await _context.Rentals
                .Where(r => r.CustomerId == customerId && !r.IsReturned)
                .Include(r => r.Car)
                .OrderBy(r => r.StartDate)
                .ToListAsync();
        }
    }
}
