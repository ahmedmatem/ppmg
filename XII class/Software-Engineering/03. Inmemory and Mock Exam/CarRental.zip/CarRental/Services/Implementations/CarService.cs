using Microsoft.EntityFrameworkCore;
using CarRental.Data;
using CarRental.Models.Entities;
using CarRental.Services.Interfaces;

namespace CarRental.Services.Implementations
{
    public class CarService : ICarService
    {
        private readonly CarRentalDbContext _context;

        public CarService(CarRentalDbContext context)
        {
            _context = context;
        }

        public async Task<List<Car>> GetAllAsync()
        {
            return await _context.Cars
                .OrderBy(c => c.Make)
                .ThenBy(c => c.Model)
                .ToListAsync();
        }

        public async Task<Car?> GetByIdAsync(int id)
        {
            return await _context.Cars
                .Include(c => c.Rentals)
                .FirstOrDefaultAsync(c => c.Id == id);
        }

        public async Task<Car> CreateAsync(Car car)
        {
            _context.Cars.Add(car);
            await _context.SaveChangesAsync();
            return car;
        }

        public async Task<bool> UpdateAsync(Car car)
        {
            if (!await _context.Cars.AnyAsync(c => c.Id == car.Id))
                return false;

            _context.Cars.Update(car);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteAsync(int id)
        {
            var car = await _context.Cars.FindAsync(id);
            if (car == null)
                return false;

            _context.Cars.Remove(car);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<List<Car>> GetAvailableCarsAsync()
        {
            return await _context.Cars
                .Where(c => c.IsAvailable)
                .OrderBy(c => c.Make)
                .ThenBy(c => c.Model)
                .ToListAsync();
        }

        public async Task<bool> SetAvailabilityAsync(int carId, bool isAvailable)
        {
            var car = await _context.Cars.FindAsync(carId);
            if (car == null)
                return false;

            car.IsAvailable = isAvailable;
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
