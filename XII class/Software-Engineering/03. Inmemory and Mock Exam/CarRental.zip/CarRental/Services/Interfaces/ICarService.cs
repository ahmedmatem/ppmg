using CarRental.Models.Entities;

namespace CarRental.Services.Interfaces
{
    public interface ICarService
    {
        Task<List<Car>> GetAllAsync();
        Task<Car?> GetByIdAsync(int id);
        Task<Car> CreateAsync(Car car);
        Task<bool> UpdateAsync(Car car);
        Task<bool> DeleteAsync(int id);

        Task<List<Car>> GetAvailableCarsAsync();

        /// <summary>
        /// Маркира колата като налична или не.
        /// </summary>
        Task<bool> SetAvailabilityAsync(int carId, bool isAvailable);
    }
}
