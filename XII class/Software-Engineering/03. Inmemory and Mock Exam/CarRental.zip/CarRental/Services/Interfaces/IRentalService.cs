using CarRental.Models.Entities;

namespace CarRental.Services.Interfaces
{
    public interface IRentalService
    {
        /// <summary>
        /// Създава нов наем, ако колата е налична и клиентът е активен.
        /// Изчислява TotalPrice на база брой дни * DailyRate.
        /// Връща true при успех, false при неуспех.
        /// </summary>
        Task<bool> CreateRentalAsync(int customerId, int carId, DateTime startDate, DateTime endDate);

        /// <summary>
        /// Отбелязва връщане на автомобил и го прави отново наличен.
        /// </summary>
        Task<bool> ReturnCarAsync(int rentalId);

        Task<Rental?> GetRentalAsync(int rentalId);

        Task<List<Rental>> GetActiveRentalsForCustomerAsync(int customerId);
    }
}
