namespace ZooWorld.Lib;

public interface ISwim
{
    void Swim(int meters);
    int TotalSwimM { get; }
}
