namespace RestaurantMenu.Lib;

public enum SpiceLevel { None, Mild, Medium, Hot, ExtraHot }
