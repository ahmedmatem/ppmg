namespace RestaurantMenu.Lib;

public interface IVeganFriendly { bool IsVegan { get; } }
