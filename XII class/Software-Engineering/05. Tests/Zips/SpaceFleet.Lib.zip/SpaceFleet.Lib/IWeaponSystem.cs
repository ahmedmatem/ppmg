namespace SpaceFleet.Lib;

public interface IWeaponSystem
{
    int Fire(int energyRequested);
}
